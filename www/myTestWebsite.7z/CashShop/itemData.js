const itemData = [
    {
        "value": "1093",
        "itemidx": "1093",
        "itemopt": "0",
        "img": "\/CashShop\/items\/a_vam.jpg",
        "label": "Fantasy - Vampire",
        "price": "500"
    },
    {
        "value": "1097",
        "itemidx": "1097",
        "itemopt": "0",
        "img": "\/CashShop\/items\/a_freed.jpg",
        "label": "Fantasia - Freed",
        "price": "500"
    },
    {
        "value": "1234",
        "itemidx": "1234",
        "itemopt": "0",
        "img": "\/CashShop\/items\/Chinese_Traditional_Dress.gif",
        "label": "Fantasy - Chinese Gala",
        "price": "500"
    },
    {
        "value": "561",
        "itemidx": "561",
        "itemopt": "0",
        "img": "",
        "label": "gm",
        "price": "1"
    }
];

export default itemData;